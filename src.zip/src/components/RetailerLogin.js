import React, { Component } from 'react'

export default class RetailerLogin extends Component {
  render() {
    return (
      <div>
        Hi Retailer
      </div>
    )
  }
}
